import { html, Component, Router, Link, render } from "../htm-preact-router/htm-preact-router.mjs";

import Header from "./Header.js";

const None = () => {
  return html`
    <h2>404 not found</h2>
  `;
}

const Footer = props => {
  return html`
  <footer>
    <h4>${props.title}</h4>
  </footer>`;
}

const Home = () => {
  return html`
    <h2>Hello World!</h2>
  `;
}

const Example = () => {
  return html`
    <h3>EXAMPLE</h3>
  `;
}

function App(props) {
  return html`
  <div>
    <${Header} title="HTM-PREACT-ROUTER" />
    <nav>
      <${Link} activeClassName="active" href="/">Home<//>
      <${Link} activeClassName="active" href="/example">Example<//>
      <${Link} activeClassName="active" href="/none">None<//>
    </nav>
    <${Router} onChange="${ e => this.setState(e)}" >
      <${Home} path="/" />
      <${Example} path="/example" />
      <${None} default />
    <//>
    <${Footer} title="${'© ' + new Date().getFullYear()}" />
  </div>
  `;
}

export default App;
