/* Utils to program faster and reduce code length */

const $ = selector => document.querySelector(selector);
const $$ = selector => document.querySelectorAll(selector);
const ael = (element, callback, evnt="click") => {
  element.addEventListener(evnt, e => {
    callback(e);
  });
}
const mode = alert;
const _ = text => {
  mode(`[DEBUG] ${text}`);
}
/* End utils */

const app = $("#app");


const initAnimation = () => {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(95, window.innerWidth / window.innerHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({ preserveDrawingBuffer: true });
  renderer.setClearColor(new THREE.Color(0xEEEEEE, 1.0));
  renderer.setSize(window.innerWidth - window.innerWidth/10, window.innerHeight - window.innerHeight /10);
  renderer.shadowMapEnabled = true;

  const planeGeometry = new THREE.PlaneGeometry(60, 20);
  const planeMaterial = new THREE.MeshLambertMaterial({color: 0xffffff });
  const plane = new THREE.Mesh(planeGeometry, planeMaterial);
  plane.receiveShadow = true;

  plane.rotation.x = -0.5 * Math.PI;
  plane.position.x = 5;
  plane.position.y = -4;
  plane.position.z = 0;

  scene.add(plane);


  const cubeGeometry = new THREE.BoxGeometry(4, 14, 4);
  const cubeMaterial = new THREE.MeshLambertMaterial({color: 0x555555});
  const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
  cube.castShadow = true;

  cube.position.x = -4;
  cube.position.y = 3;
  cube.position.z = 0;

  scene.add(cube);


  const sphereGeometry = new THREE.SphereGeometry(4, 10, 10);
  const sphereMaterial = new THREE.MeshLambertMaterial({color: 0x9f9f59});
  const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);

  sphere.position.x = -4;
  sphere.position.y = 13.8;
  sphere.position.z = 0;
  sphere.castShadow = true;

  scene.add(sphere);

  camera.position.x = -30;
  camera.position.y = 40;
  camera.position.z = 30;
  camera.lookAt(scene.position);


  const spotLight = new THREE.SpotLight(0xffffff);
  spotLight.position.set(-40, 60, -10);
  spotLight.castShadow = true;
  scene.add(spotLight);


  app.appendChild(renderer.domElement);
  renderer.render(scene, camera);

  let bounce = false;
  let bounceOnce = false;
  const ballFallingAnimation = ball => {
    ball.position.x += 0.2;
    ball.position.y += 0.02;
    if (bounce == true) {
      ball.position.y += 0.1;
      if (ball.position.y > 6) {
        bounce = false;
	bounceOnce = true;
      }
    } else {

      if (ball.position.x >= 1) {
        if (ball.position.y > 0) {
          ball.position.y -= 0.15;
        } else {
	  if (!bounceOnce) {
            bounce = true;
	  } else {
            ball.position.x -= 0.01;
	    ball.position.y -= 0.3;
	    if (ball.position.y < -4) {
              ball.material.transparent = true;
	      ball.material.opacity -= 0.0026;
	    }
	  }
        }
      }
    }

    camera.lookAt(ball.position);
    renderer.render(scene, camera);
    if (ball.material.opacity <= 0) {
      return;
    }
    requestAnimationFrame(() => ballFallingAnimation(ball));
    // invertir z del click del usuario respecto al centro de la bola
  }

  let firstPersonCameraPerspective = false;
  ael(app, e => {

    const vector = new THREE.Vector3(( e.clientX / window.innerWidth ) * 2 - 1, -( e.clientY / window.innerHeight ) * 2 + 1, 0.5).unproject(camera);
    const raycaster = new THREE.Raycaster(camera.position, vector.sub(camera.position).normalize());                                                     
    const intersects = raycaster.intersectObjects([ sphere ]);      
    if (intersects.length > 0) {
      ballFallingAnimation(intersects[0].object);
    } else {
      if (!firstPersonCameraPerspective) {
        camera.position.y = 8;
        camera.position.z = 10;
        camera.position.x = -30;
        camera.lookAt(sphere.position);
	firstPersonCameraPerspective = true;
      } else {
        camera.position.x = -30;
	camera.position.y = 40;
	camera.position.z = 30;
	camera.lookAt(scene.position);
	firstPersonCameraPerspective = false;
      }
    }

    renderer.render(scene, camera);
  });
}

initAnimation();

