IMPORTANT, This project is not using typescript, BUT uses typescript compiler to translate JSX sintax found in your javascript source files to javascript.

What i have to do?

Run the command tsc without arguments. If you don't have it, install it using npm:
npm install -g typescript
and now you can run the command:
npx tsc

The jsx code will be compiled into the folder ./compiled/js/
You can serve your code. 

NOTICE:
This is not a REACT replacement or a Virtual DOM alternative, this is just sintactical sugar to create elements using JSX sintax.
I also include a small parser to allow you to use style objects. 
