/* Utils to program faster and reduce code length */
const $ = selector => document.querySelector(selector);
const $$ = selector => document.querySelectorAll(selector);
const ael = (element, callback, evnt="click") => {
  element.addEventListener(evnt, e => {
    callback(e);
  });
}
const mode = alert;
const _ = text => {
  mode(`[DEBUG] ${text}`);
} 
/* End utils */

const Home = {
  template: `<div class="view home">This is my <b>home</b> view</div>`
};

const About = {
  template: `<div class="view about">This is my <b>about</b> view</div>`
};

const routes = [
  { path: '/', component: Home },
  { path: '/home', component: Home },
  { path: '/about', component: About }
];

const router = new VueRouter({
  routes: routes
})

const app = new Vue({
  router,
  watch: {
    '$route' (to, from) {

    }
  }
}).$mount("#app");


/* Await code */
/*
(async () => {

})();
*/
/* End Await */
